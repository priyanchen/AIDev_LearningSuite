# Credit Card Fraud Detection — Course Project

Logistic regression pipeline + Streamlit interface, following the lesson of 02.09.2026.

---

## 1. Setup

```bash
# From inside this folder
python -m venv venv

# Activate
source venv/bin/activate          # Mac / Linux
venv\Scripts\activate             # Windows

# Install
pip install -r requirements.txt
```

## 2. Get the dataset

Download `card_transdata.csv` (or the course dataset `credit_card_fraud.csv`) from one of:

- **Kaggle:** https://www.kaggle.com/datasets/dhanushnarayananr/credit-card-fraud
- **Course Drive folder:** https://drive.google.com/drive/u/0/folders/1ixKo5VixZ5k4LGHXZdp-1ficgeBc3g6E

Place the CSV in this folder and rename it to `data.csv` (or edit the path at the top of the notebook).

## 3. Train the model

```bash
jupyter notebook fraud_pipeline.ipynb
```

Run every cell from top to bottom. The final cells save two artifacts:

- `model.pkl` — the trained logistic regression
- `scaler.pkl` — the fitted MinMaxScaler
- `feature_columns.pkl` — the exact column order used at training time

## 4. Run the Streamlit app

```bash
streamlit run app.py
```

The interface opens at `http://localhost:8501`. Enter transaction values, adjust the decision threshold, and receive a fraud probability with the model's verdict.

---

## Project layout

```
fraud_detection_project/
├── README.md
├── requirements.txt
├── fraud_pipeline.ipynb    # EDA → preprocessing → training → evaluation → threshold sweep
├── app.py                  # Streamlit predictor
└── (generated after training)
    ├── model.pkl
    ├── scaler.pkl
    └── feature_columns.pkl
```

## Discipline reminders (from the lesson)

- Fit the scaler on **train only** — never the full dataset.
- **Accuracy is meaningless** on imbalanced fraud data — read precision, recall, F1.
- **Threshold ≠ 0.5** by default. Sweep it, choose by domain cost.
- Drop ID columns. Handle `transaction_hour` as **cyclical** (sin/cos), not raw numeric.
- Use `stratify=y` when splitting imbalanced data.
